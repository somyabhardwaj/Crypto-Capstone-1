import React from 'react';
import LineChart from './components/Charts/LineChart.js';
import './App.css';
import Navbar from './components/Navbar/Navbar.js';
import Home from './components/Home/Home.js';
function App() {
  return (
    <div>
    
<Navbar />

    <Home /> 

      
    </div>
  )
}

export default App
