import { createSlice } from "@reduxjs/toolkit";

const timebuttonSlice = createSlice({

    name:'timeButton',
    inititialState:7,
    reducers:{
        
    }
})